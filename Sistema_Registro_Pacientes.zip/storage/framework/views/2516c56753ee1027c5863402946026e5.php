<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="bg-white p-5 rounded shadow-sm border">
            <h2 class="text-secondary">Bienvenido, Doctor</h2>
            <p class="lead">Gestione sus fichas de tratamiento y pacientes aquí.</p>
        <div class="mt-4">
            <a href="<?php echo e(route('doctor.patients.index')); ?>" class="btn btn-primary px-4">Ver Pacientes</a>
            <a href="<?php echo e(route('doctor.patients.create')); ?>" class="btn btn-outline-secondary px-4">Nuevo Paciente</a>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema_Registro_Pacientes\resources\views/doctor/dashboard.blade.php ENDPATH**/ ?>