<!DOCTYPE html>
<html lang="es">
<head>
    <style>
        body { font-family: sans-serif; font-size: 12px; }
        .header { text-align: center; font-weight: bold; font-size: 18px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid black; padding: 5px; text-align: center; }
        .info-box { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="header">CLINICA SACITEB - FICHA DE TRATAMIENTO</div>
    <div class="info-box">
        <strong>Paciente:</strong> <?php echo e($sheet->patient->names); ?> <?php echo e($sheet->patient->paternal_surname); ?> <?php echo e($sheet->patient->maternal_surname); ?><br>
        <strong>DNI:</strong> <?php echo e($sheet->patient->dni); ?> | <strong>Celular:</strong> <?php echo e($sheet->patient->phone); ?> | <strong>Edad:</strong> <?php echo e($sheet->patient->birth_date ? \Carbon\Carbon::parse($sheet->patient->birth_date)->age : 'N/A'); ?><br>
        <strong>Dirección:</strong> <?php echo e($sheet->patient->address); ?><br>
        <strong>Diagnóstico:</strong> <?php echo e($sheet->diagnosis); ?>

    </div>
    <table>
        <thead>
            <tr><th>MES/DIA</th> <?php for($i=1; $i<=31; $i++): ?> <th><?php echo e($i); ?></th> <?php endfor; ?> </tr>
        </thead>
        <tbody>
            <tr>
                <td>Atención</td>
                <?php for($i=1; $i<=31; $i++): ?>
                    <td><?php echo e($sheet->sessions->where('day', $i)->count() > 0 ? 'X' : ''); ?></td>
                <?php endfor; ?>
            </tr>
        </tbody>
    </table>
    <h3>Detalle de Atenciones</h3>
    <ul style="list-style-type: none; padding-left: 0;">
        <?php $__currentLoopData = $sheet->sessions->sortByDesc(fn($s) => $s->year . $s->month . $s->day); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li style="margin-bottom: 10px; padding: 8px; border-bottom: 1px solid #eee;">
                <strong>Fecha:</strong> <?php echo e($s->day); ?>/<?php echo e($s->month); ?>/<?php echo e($s->year); ?><br>
                <strong>Tratamiento:</strong> <?php echo e($s->notes); ?>

                <?php if($s->payment_details): ?>
                    <br><strong style="color: #d9534f;">Detalles del Pago:</strong> <?php echo e($s->payment_details); ?>

                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Sistema_Registro_Pacientes\resources\views/doctor/treatments/pdf.blade.php ENDPATH**/ ?>