<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-secondary btn-sm mb-2">
                <i class="bi bi-arrow-left"></i> Regresar al Panel
            </a>
            <h2 class="mb-0">Pacientes</h2>
        </div>
        <a href="<?php echo e(route('doctor.patients.create')); ?>" class="btn btn-primary btn-lg">+ Nuevo Paciente</a>
    </div>

    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Nombre Completo</th>
                        <th>DNI</th>
                        <th>Celular</th>
                        <th>Edad</th>
                        <th>Direccion</th>
                        <th class="text-center">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($patient->names); ?> <?php echo e($patient->paternal_surname); ?> <?php echo e($patient->maternal_surname); ?></td>
                            <td><?php echo e($patient->dni); ?></td>
                            <td><?php echo e($patient->phone); ?></td>
                            <td><?php echo e($patient->birth_date ? \Carbon\Carbon::parse($patient->birth_date)->age : 'N/A'); ?></td>
                            <td><?php echo e($patient->address); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('doctor.patients.edit', $patient)); ?>"
                                    class="btn btn-outline-warning btn-sm">Editar</a>

                                <?php if($patient->treatmentSheets->count() > 0): ?>
                                    
                                    <a href="<?php echo e(route('doctor.treatments.show', $patient->treatmentSheets->first()->id)); ?>"
                                        class="btn btn-outline-success btn-sm">Ver Ficha</a>
                                <?php else: ?>
                                    
                                    <a href="<?php echo e(route('doctor.treatments.create', $patient)); ?>"
                                        class="btn btn-outline-primary btn-sm">Nueva Ficha</a>
                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema_Registro_Pacientes\resources\views/doctor/patients/index.blade.php ENDPATH**/ ?>