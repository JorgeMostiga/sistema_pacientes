<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-8">
        <div class="card shadow-sm border-0 p-4">
            <h3 class="mb-4">Nueva Ficha: <?php echo e($patient->names); ?></h3>
            <form action="<?php echo e(route('doctor.treatments.store', $patient)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label">Diagnóstico</label>
                    <textarea name="diagnosis" class="form-control" rows="4" required></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label">Método de Pago</label>
                    <select name="payment_method" class="form-select">
                        <option value="efectivo">Efectivo</option>
                        <option value="yape">Yape</option>
                        <option value="plin">Plin</option>
                        <option value="tarjeta">Tarjeta</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-success btn-lg w-100">Crear Ficha</button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.doctor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema_Registro_Pacientes\resources\views/doctor/treatments/create.blade.php ENDPATH**/ ?>