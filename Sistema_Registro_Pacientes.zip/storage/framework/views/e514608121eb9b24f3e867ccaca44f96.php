<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Receptores de Pago</h2>
        <a href="<?php echo e(route('admin.payment-receivers.create')); ?>" class="btn btn-primary">
            <i class="bi bi-plus-lg"></i> Nuevo Receptor
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Nombre</th>
                            <th>Teléfono</th>
                            <th>Métodos Aceptados</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $receivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $receiver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td class="fw-bold"><?php echo e($receiver->name); ?></td>
                                <td><?php echo e($receiver->phone_number ?? 'N/A'); ?></td>
                                <td>
                                    <?php if($receiver->accepts_yape): ?> <span class="badge bg-purple text-white">Yape</span> <?php endif; ?>
                                    <?php if($receiver->accepts_plin): ?> <span class="badge bg-info text-dark">Plin</span> <?php endif; ?>
                                    <?php if($receiver->accepts_efectivo): ?> <span class="badge bg-success">Efectivo</span> <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('admin.payment-receivers.edit', $receiver)); ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="bi bi-pencil"></i>
                                    </a>
                                    <form action="<?php echo e(route('admin.payment-receivers.destroy', $receiver)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Estás seguro de eliminar este receptor?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">No hay receptores de pago registrados.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-3">
                <?php echo e($receivers->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<style>
    .bg-purple { background-color: #7c3aed; }
</style>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema_Registro_Pacientes\resources\views/admin/payment-receivers/index.blade.php ENDPATH**/ ?>