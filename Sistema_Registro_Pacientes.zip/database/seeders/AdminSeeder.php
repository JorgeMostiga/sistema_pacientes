<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        User::create([
            'name' => 'Administrador Principal',
            'usuario' => 'admin',
            'email' => 'admin@sistemapacientes.com',
            'password' => Hash::make('admin123'),
            'role' => 'admin',
        ]);
    }
}
