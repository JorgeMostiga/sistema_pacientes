<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card p-4">
            <h1>Bienvenido, Admin</h1>
            <p>Selecciona una opción del menú superior para comenzar a gestionar el sistema.</p>
            
            <div class="row mt-4">
                <div class="col-md-12">
                    <div class="card bg-light">
                        <div class="card-body">
                            <h5 class="card-title">Gestionar Usuarios</h5>
                            <p class="card-text">Crea, edita o elimina usuarios del sistema (Doctores, Admins, etc.).</p>
                            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-primary">Ir a Usuarios</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\Sistema_Registro_Pacientes\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>